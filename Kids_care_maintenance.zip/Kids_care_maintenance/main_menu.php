<li><a href="index.php" class="link link--yaku"><span>H</span><span>O</span><span>M</span><span>E</span></a></li>
						<li><a href="admin.php" class="link link--yaku"><span>A</span><span>D</span><span>M</span><span>I</span><span>N</span></a></li>
						<li><a href="#" class="dropdown-toggle link link--yaku" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span>P</span><span>E</span><span>D</span><span>I</span><span>A</span><span>T</span><span>R</span><span>I</span><span>C</span><span>I</span><span>A</span><span>N</span> <span class="caret"></span></a>
							<ul class="dropdown-menu">
								<li><a href="pediatrician_login.php" class="link link--yaku"><span>L</span><span>O</span><span>G</span> <span>I</span><span>N</span></a></li>
								<li><a href="pediatrician_register.php" class="link link--yaku"><span>R</span><span>E</span><span>G</span><span>I</span><span>S</span> <span>T</span><span>E</span><span>R</span></a></li>
							</ul>
						</li>
						 <li><a href="#" class="dropdown-toggle link link--yaku" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span>P</span><span>A</span><span>R</span><span>E</span><span>N</span><span>T</span><span>S</span> <span class="caret"></span></a>
							<ul class="dropdown-menu">
								<li><a href="parent_login.php" class="link link--yaku"><span>L</span><span>O</span><span>G</span> <span>I</span><span>N</span></a></li>
								<li><a href="parent_register.php" class="link link--yaku"><span>R</span><span>E</span><span>G</span><span>I</span><span>S</span> <span>T</span><span>E</span><span>R</span></a></li>
							</ul>
						</li>