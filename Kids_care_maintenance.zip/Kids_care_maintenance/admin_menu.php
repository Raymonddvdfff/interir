<li><a href="admin_home.php" class="link link--yaku"><span>Home</span></a></li>
<li><a href="admin_add_vaccination.php" class="link link--yaku"><span>Add Vaccination</span></a></li>
<li><a href="admin_add_food.php" class="link link--yaku"><span>Add Food</span></a></li>
<li><a href="admin_add_product.php" class="link link--yaku"><span>Add Product</span></a></li>
<li><a href="index.php" class="link link--yaku"><span>Logout</span></a></li>
 