<?php
$connect=mysql_connect("localhost","root","");
mysql_select_db("php_kids_care_maintenance",$connect);

?>