<li><a href="pediatrician_home.php" class="link link--yaku"><span>Home</span></a></li>
<li><a href="pediatrician_appointment.php" class="link link--yaku"><span>Appointment</span></a></li>
 
<li><a href="index.php" class="link link--yaku"><span>Logout</span></a></li>
 