-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 20, 2020 at 02:01 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `php_kids_care_maintenance`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `id` varchar(100) NOT NULL,
  `user` varchar(100) NOT NULL,
  `did` varchar(100) NOT NULL,
  `dname` varchar(100) NOT NULL,
  `cdate` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `report` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`id`, `user`, `did`, `dname`, `cdate`, `status`, `report`) VALUES
('1', 'sham', '1', 'arun', '20-10-20', '0', '0');

-- --------------------------------------------------------

--
-- Table structure for table `food_details`
--

CREATE TABLE `food_details` (
  `id` int(100) NOT NULL,
  `food_name` varchar(100) NOT NULL,
  `age` varchar(100) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `report` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `food_details`
--

INSERT INTO `food_details` (`id`, `food_name`, `age`, `fname`, `status`, `report`) VALUES
(1, 'fname', '25', 'parboiled.jpg', '0', '0'),
(2, 'fname', '23', 'Green_Digital.webp', '0', '0');

-- --------------------------------------------------------

--
-- Table structure for table `parent_details`
--

CREATE TABLE `parent_details` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `contact` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `report` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `parent_details`
--

INSERT INTO `parent_details` (`id`, `name`, `contact`, `email`, `address`, `username`, `password`, `status`, `report`) VALUES
(1, 'sham', '987654310', 'sham@gmail.com', 'trichy', 'sham', '123', '0', '0');

-- --------------------------------------------------------

--
-- Table structure for table `parent_purchase`
--

CREATE TABLE `parent_purchase` (
  `id` int(100) NOT NULL,
  `user` varchar(100) NOT NULL,
  `pid` varchar(100) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `category` varchar(100) NOT NULL,
  `age` varchar(100) NOT NULL,
  `price` varchar(100) NOT NULL,
  `qty` varchar(100) NOT NULL,
  `total` varchar(100) NOT NULL,
  `card` varchar(100) NOT NULL,
  `holder` varchar(100) NOT NULL,
  `cvv` varchar(100) NOT NULL,
  `ex_date` varchar(100) NOT NULL,
  `cdate` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `report` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `parent_purchase`
--

INSERT INTO `parent_purchase` (`id`, `user`, `pid`, `product_name`, `category`, `age`, `price`, `qty`, `total`, `card`, `holder`, `cvv`, `ex_date`, `cdate`, `status`, `report`) VALUES
(1, 'sham', '', 'pname', 'veg', '25', '500', '1', '500', '3423423', 'sham', '987', '12-12-2020', '20-10-20', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `pediatrician_details`
--

CREATE TABLE `pediatrician_details` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `contact` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `qualification` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `report` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pediatrician_details`
--

INSERT INTO `pediatrician_details` (`id`, `name`, `contact`, `email`, `address`, `qualification`, `username`, `password`, `status`, `report`) VALUES
(1, 'arun', '987643210', 'arunextazee@gmail.com', 'trichy', 'MBBS', 'arun', '123', '0', '0');

-- --------------------------------------------------------

--
-- Table structure for table `product_details`
--

CREATE TABLE `product_details` (
  `id` int(100) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `category` varchar(100) NOT NULL,
  `age` varchar(100) NOT NULL,
  `price` varchar(100) NOT NULL,
  `quantity` varchar(100) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `report` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_details`
--

INSERT INTO `product_details` (`id`, `product_name`, `category`, `age`, `price`, `quantity`, `fname`, `status`, `report`) VALUES
(1, 'pname', 'veg', '25', '500', '50', 'sd.jpg', '0', '0');

-- --------------------------------------------------------

--
-- Table structure for table `vaccination_details`
--

CREATE TABLE `vaccination_details` (
  `id` int(100) NOT NULL,
  `vaccination_name` varchar(100) NOT NULL,
  `age` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `report` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vaccination_details`
--

INSERT INTO `vaccination_details` (`id`, `vaccination_name`, `age`, `status`, `report`) VALUES
(1, 'vname', '25', '0', '0');
