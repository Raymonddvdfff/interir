<li><a href="parent_home.php" class="link link--yaku"><span>Home</span></a></li>
<li><a href="parent_vaccination.php" class="link link--yaku"><span>Vaccination</span></a></li>
<li><a href="parent_food.php" class="link link--yaku"><span>Food</span></a></li>
<li><a href="parent_product.php" class="link link--yaku"><span>Product</span></a></li>
<li><a href="parent_appointment.php" class="link link--yaku"><span>Appointment</span></a></li>
<li><a href="parent_appointment.php" class="link link--yaku"><span></span></a></li>
<li><a href="parent_status.php" class="link link--yaku"><span>Status</span></a></li>
<li><a href="index.php" class="link link--yaku"><span>Logout</span></a></li>
 