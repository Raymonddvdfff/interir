 <?php
include("dbconnect.php");
session_start();
extract($_POST);
  $date =date("d-m-y");
$user=$_SESSION['user'];
$id1=$_REQUEST['id'];
$dname="";
   $xyz=mysql_query("select * from pediatrician_details where id='$id1'");
while($row1=mysql_fetch_array($xyz))
				   {
				   $dname=$row1['username'];
				   }
$max_qry = mysql_query("select max(id) from appointment");
   $max_row = mysql_fetch_array($max_qry); 
   $id=$max_row['max(id)']+1;
$qry=mysql_query("insert into appointment values('$id','$user','$id1','$dname','$date','0','0')");

if($qry)
{
?>
<script language="javascript">
alert("Booking Success..");
window.location.href="parent_status.php";
</script>
<?php
}
else
{
?>
<script language="javascript">
alert("Failed..");
 </script>
<?php
} 

?>